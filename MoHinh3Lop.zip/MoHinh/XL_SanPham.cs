﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication11.Entity;
using WebApplication11.DAL;

namespace WebApplication11.Business
{
    public class XL_SanPham
    {
        public static List<SanPham> DocDanhSach(string filePath)
        {
            return LT_SanPham.DocDanhSach(filePath);
        }
    }
}  