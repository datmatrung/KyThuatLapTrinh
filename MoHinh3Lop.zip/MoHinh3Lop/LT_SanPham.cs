﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using WebApplication11.Entity;

namespace WebApplication11.DAL
{
    public class LT_SanPham
    {
        public static List<SanPham> DocDanhSach(string filePath)
        {
            List<SanPham> ds = new List<SanPham>();
            StreamReader reader = new StreamReader(filePath);
            int N = int.Parse(reader.ReadLine());
            for (int i = 0; i < N; i++)
            {
                string s = reader.ReadLine();
                string[] M = s.Split(',');
                SanPham sp = new SanPham();
                sp.MaSP = int.Parse(M[0]);
                sp.TenSP = M[1];
                sp.Gia = int.Parse(M[2]);
                ds.Add(sp);
            }
            reader.Close();
            return ds;
        }
    }
}