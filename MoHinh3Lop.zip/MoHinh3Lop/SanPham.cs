﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication11.Entity
{
    public struct SanPham
    {
        public int MaSP;
        public string TenSP;
        public int Gia;
    }
}